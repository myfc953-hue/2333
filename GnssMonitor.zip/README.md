# 卫星监视器 GnssMonitor

一个 Android 应用：每 0.5 秒刷新一次界面，

- 上部：当前经纬度（6 位小数）
- 中部：当前移动速度（km/h 与 m/s）
- 下部：卫星星数（可见数量 / 参与定位数量）

## 运行要求

- Android 6.0 (API 24) 及以上
- 需要授予「定位」权限，并建议打开系统「高精度定位」
- 首次启动在室内可能搜不到卫星，到室外空旷处等待即可

## 速度如何计算

优先使用系统 GPS 输出速度；如果设备未提供速度，则用两次定位点的
距离差除以时间差估算（米/秒），再换算成 km/h。

## 怎么得到 APK

本机（手机）没有 Java / Android SDK，无法直接编译。用 GitHub Actions 云端打包：

1. 在 GitHub 新建一个空仓库
2. 把本目录全部文件上传（网页版 Add file → Upload files 即可）
3. 打开仓库的 Actions 页面，等待 "Build APK" 跑完
4. 在该次运行页面的 Artifacts 里下载 `GnssMonitor-apk`
5. 解压得到 `app-debug.apk`，传到手机安装即可

## 本地打包（可选）

装有 Android SDK 的电脑上执行：

```
gradle assembleDebug
```

产物在 `app/build/outputs/apk/debug/app-debug.apk`。